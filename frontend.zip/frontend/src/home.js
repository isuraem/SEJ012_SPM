import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Event from "./components/eventReservationManagement/Event";
import addVehicle from "./components/vehicleManagement/addVehicle"

function Home() {
  return (
    <Router>
      <Switch>
        <Route path="/addEvent" exact component={Event} />
        <Route path="/addVehicle" exact component={addVehicle} />
      </Switch>
    </Router>
  );
}

export default Home;
